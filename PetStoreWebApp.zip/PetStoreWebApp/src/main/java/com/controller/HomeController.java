package com.controller;

import java.util.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.*;
import com.model.*;

@Controller
public class HomeController {
	@RequestMapping("/")
	public ModelAndView getIndex() {
		ModelAndView mymv = new ModelAndView("/index");
		return mymv;
	}

	@RequestMapping("/pets")
	public ModelAndView getIndex1() {
		ModelAndView mymav = new ModelAndView("/PetStoreHome");
		Pets pet = new Pets("ABC", "dog", 5);
		mymav.addObject("pet", pet);
		return mymav;
	}

	@RequestMapping("/petstore")
	public ModelAndView MyStore() {
		List<PetStore> petstore = new ArrayList<PetStore>();
		petstore.add(new PetStore("James Pet Store", "Aurangabad"));
		petstore.add(new PetStore("Tom Pet Store", "Nagpur"));
		petstore.add(new PetStore("Jerry Pet Store", "Jalna"));

		ModelAndView mymav1 = new ModelAndView("/PetStore");
		mymav1.addObject("petstore",petstore);
		return mymav1;
	}
	
	@RequestMapping("/addpet")
	public ModelAndView addPetModel() {
	ModelAndView addpetmodel = new ModelAndView("/AddPet");
		return addpetmodel;
	}
	
	@RequestMapping(value="/addpet", method=RequestMethod.POST)
	public ModelAndView addPetDetails() {
		return null;
		
	}
}
