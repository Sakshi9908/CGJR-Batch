package com.jpaexample.criteriaquery;

public class EmployeeFetchEx {

}
